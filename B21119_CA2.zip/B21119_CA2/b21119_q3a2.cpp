#include<bits/stdc++.h>
using namespace std;

struct Node
{
    int val;
    Node *prev,*next;

    Node(int v)
    {
        val=v;
        prev=next=NULL;
    }
};
struct DoubleLinkedList
{
    Node *first, *last, *cleanend;
    int len;

    DoubleLinkedList()
    {
        first=last=cleanend=NULL;
        len=0;
    }
    void insert_dirty(int val)
    {
        Node *newnode= new Node(val);
        if(first==NULL)
        {
            cleanend=last=first=newnode;
        }
        else
        {
            newnode->prev=last;
            last->next=newnode;
            last=newnode;
        }
        len+=1;
    }

    void insert_clean(int val,int thres)
    {
        Node *newnode= new Node(val);
        if(first==NULL)
        {
            cleanend=last=first=newnode;
        }
        else
        {
            if((first->val)<thres){
                newnode->next=first;
                first=cleanend=newnode;
            }
            else{
            newnode->next=cleanend->next;
            cleanend->next->prev=newnode;
            cleanend->next=newnode;
            cleanend=newnode;
        }}
        len+=1;
    }
};
int main()
{
    DoubleLinkedList list1;
    cout<<"Enter the number of plates: ";
    int plates;
    cin>>plates;
    int t;
    cout<<"Enter the threshold value: ";
    cin>>t;
    cout<<"Enter the cleanliness score of the plates: ";
    for(int i=0;i<plates;i++){
        int cs;
        cin>>cs;
        if (cs>=t){
            list1.insert_clean(cs,t);
        }
        else{
            list1.insert_dirty(cs);
        }
    }
    cout<<"The arranged order is: ";
    Node *itr=list1.first;
    while(itr!=NULL)
     {
         cout<<itr->val<<" ";
         itr=itr->next;
    }
    cout<<endl;
    return 0;
}
