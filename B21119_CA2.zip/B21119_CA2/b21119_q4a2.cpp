#include<iostream>
using namespace std;
int main(){
    cout<<"Enter the length of array: ";
    int n;
    cin>>n;
    int A[n];
    cout<<"Enter the elements in array \"A\" : "<<endl;
    for(int i=0;i<n;i++){
        cin>>A[i];
    }
    int B[n]={0};
    int point =0;
    for (int i=0;i<n;i++){
            int left=0;
            int right=0;
        for(int j=0;j<i;j++){
            if(A[i]>A[j]) left++;
        }
        for(int j= i+1;j<n;j++){
            if(A[i]>A[j]) right++;
        }
        if(right>left){
            B[point]=i;
            point++;
        }
    }
    cout<<"The required array is: "<<endl;
    for(int k=0;k<point;k++){
        cout<<B[k]<<" ";
    }
}
