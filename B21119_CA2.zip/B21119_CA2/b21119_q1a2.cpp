#include <bits/stdc++.h>
using namespace std;
int func(int n,int arr[],int len){
    priority_queue<int,vector<int>,greater<int>> pq;
    for(int i=0;i<len;i++){
        pq.push(arr[i]);
    }
    int ct=0;
    int ans;
    while(ct<n){
        ans=pq.top();
        pq.pop();
        if(ans!=pq.top()){
            ct++;
            for(int i=0;i<len;i++){
                pq.push(ans*arr[i]);
            }
        }
    }
    return ans;
}
int main(){
    cout<<"Enter the number of elements in the array: ";
    int arrlen;
    cin>>arrlen;
    if(arrlen<=0){
        cout<<"Length can't be less than 1"<<endl;
        return 0;
        }
    else{
    int arr[arrlen];
    cout<<"Enter the values of elements in the array: ";
    for(int i=0;i<arrlen;i++){
        cin>>arr[i];
    }
    int n;
    cout<<"Enter n: ";
    cin>>n;
    if(n<=0) cout<<"Invalid Input"<<endl;
    else {cout<<"Nth Super Ugly number is: ";
        cout<<func(n,arr,arrlen)<<endl;
    }
    }
    }

